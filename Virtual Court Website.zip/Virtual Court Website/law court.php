<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Judicial Service - Virtual Court Website</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Law Firm Website Template" name="keywords">
        <meta content="Law Firm Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@1,600;1,700;1,800&family=Roboto:wght@400;500&display=swap" rel="stylesheet"> 
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
        <div class="wrapper">
            <!-- Top Bar Start -->
            <div class="top-bar">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="logo">
                                <a href="index.html">
                                    
                                    <img src="img/4.png" alt="Logo"> <h1>Virtual Court</h1>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <div class="top-bar-right">
                                <div class="text">
                                    <h2>8:00 AM - 4:00 PM</h2>
                                    <p>Opening Hour Mon - Fri</p>
                                </div>
                                <div class="text">
                                    <h2>+233 24 443 3763</h2>
                                    <p>Call Us For More Enquiries</p>
                                </div>
                                <div class="social">
                                    <a href=""><i class="fab fa-twitter"></i></a>
                                    <a href=""><i class="fab fa-facebook-f"></i></a>
                                    <a href=""><i class="fab fa-whatsapp"></i></a>
                                    <a href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Top Bar End -->

            <!-- Nav Bar Start -->
            <div class="nav-bar">
                <div class="container-fluid">
                    <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                        <a href="#" class="navbar-brand">MENU</a>
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                            <div class="navbar-nav mr-auto">
                                <a href="index.php" class="nav-item nav-link">Home</a>
                                <a href="about.php" class="nav-item nav-link">About</a>
                                <a href="service.php" class="nav-item nav-link">Practice</a>
                                <a href="law court.php" class="nav-item nav-link active">Law Court</a>
                                <a href="contact.php" class="nav-item nav-link">Contact</a>
                                <a href="message.php" class="nav-item nav-link">Message</a>
                            </div>
                            </div>
                            <div class="ml-auto">
                                <a class="btn" href="booking.php">Get Appointment</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
            <!-- Nav Bar End -->
            
            
            <!-- Page Header Start -->
            <div class="page-header">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2>Law Courts</h2>
                        </div>
                        <div class="col-12">
                            <a href="index.php">Home</a>
                            <a href="">Law Courts</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Page Header End -->


            <!-- Blog Start -->
            <div class="blog">
                <div class="container">
                    <div class="section-header">
                        <h2>Law Courts</h2>
                    </div>
                    <div class="row blog-page">
                        <div class="col-lg-4 col-md-6 blog-item">
                            <img src="img/1.jpg" alt="Blog">
                            <h3>Supreme Court</h3>
                            <p>
                            The Supreme Court is the highest Court in the administration of justice in Ghana.
The Court is presided over by the Chief Justice and in his absence the most senior of the Justices of the Supreme Court, as constituted shall preside. Judges who sit in the Supreme Court are referred to as Justices of the Supreme Court.


                            </p>
                            <a class="btn" href="https://judicial.gov.gh/index.php/the-supreme-court">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                        <div class="col-lg-4 col-md-6 blog-item">
                            <img src="img/DSC_0529-scaled.jpg" alt="Blog">
                            <h3>Court Of Appeal</h3>
                            <p>
                            It is the second highest Court in the hierarchy of the Superior Courts.
Judges who sit in the Court of Appeal are referred to as Justices of the Court of Appeal. As the name implies, all appeal cases from the High Courts, Regional Tribunals and Civil appeals from Circuit Courts are brought to the Court of Appeal.

                            </p>
                            <a class="btn" href="https://judicial.gov.gh/index.php/the-court-of-appeal">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                        <div class="col-lg-4 col-md-6 blog-item">
                            <img src="img/22.jpg" alt="Blog">
                            <h3>High Court </h3>
                            <p>
                            The High Court is the third highest Court in the hierarchy of the Superior Courts. Judges who sit in the High Court are referred to as Justices of the High Court.
It is duly constituted by a single Judge, unless the Court is required to sit with jurors or assessors. It has original jurisdiction in all civil and criminal matters. It also has appellate jurisdiction in appeals from the District Court and criminal appeals from the Circuit Court. 

                            </p>
                            <a class="btn" href="https://judicial.gov.gh/index.php/the-high-court">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                        <div class="col-lg-4 col-md-6 blog-item">
                            <img src="img/55.jpeg" alt="Blog">
                            <h3>Circuit Court</h3>
                            <p>
                            Judges who sit at the Circuit Court are referred to as Circuit Court Judges.
The Circuit Court has jurisdiction in civil actions. However, there are restrictions on most of its values. It also has jurisdiction in all criminal matters other than treason and offenses punishable by death. Furthermore, it has jurisdiction in matters involving custody of children. Circuit Courts are located in the regional and some district capitals of Ghana.

                            </p>
                            <a class="btn" href="https://judicial.gov.gh/index.php/the-circuit-court">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                        <div class="col-lg-4 col-md-6 blog-item">
                            <img src="img/unnamed.jpg" alt="Blog">
                            <h3>District Court</h3>
                            <p>
                            The District Court is the lowest in the hierarchy of all Courts in the country and it makes the largest number of Courts. The Family Court, Juvenile Court, and Motor Court are all District Courts and NOT District Magistrate Courts. They are located in most Districts in Ghana and are presided over by Magistrates.
                            </p>
                            <a class="btn" href="https://judicial.gov.gh/index.php/the-district-court">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
                    </div>
                   
                </div>
            </div>
            <!-- Blog End -->




            <!-- Footer Start -->
            <div class="footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-lg-4">
                            <div class="footer-about">
                                <h2>About Us</h2>
                                <p>
                                Judicial Service Virtual Court is a platform that enables court proceedings to take place remotely. They allow judegs, lawyers, and litigants to participate in hearings via video conferencing and digital document submissions. This system enhances accessibility, reduces delays and minimizes the need for physical presence in the courtroom.
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-8">
                            <div class="row">
                        <div class="col-md-6 col-lg-4">
                            <div class="footer-link">
                                <h2>Case Areas</h2>
                                <a href="civil case.php">Civil Cases</a>
                                <a href="family case.php">Family Cases</a>
                                <a href="business case.php">Business Cases</a>
                                <a href="education case.php">Education Cases</a>
                                <a href="criminal case.php">Criminal Cases</a>
                                <a href="cyber case.php">Cyber Cases</a>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="footer-link">
                                <h2>Useful Pages</h2>
                                <a href="about.php">About Us</a>
                                <a href="service.php">Practices</a>
                                <a href="team.php">Our Team</a>
                                <a href="law court.php">Law Courts</a>
                                
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="footer-contact">
                                <h2>Get In Touch</h2>
                                <p><i class="fa fa-map-marker-alt"></i>Court of Appeal, Kumasi-Ghana</p>
                                <p><i class="fa fa-phone-alt"></i>+233 24 443 3763</p>
                                <p><i class="fa fa-envelope"></i>ashford.mensah@jsg.gov</p>
                                <div class="footer-social">
                                    <a href=""><i class="fab fa-twitter"></i></a>
                                    <a href=""><i class="fab fa-facebook-f"></i></a>
                                    <a href=""><i class="fab fa-youtube"></i></a>
                                    <a href=""><i class="fab fa-instagram"></i></a>
                                    
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
               
            <!-- Footer End -->
            
            <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
        </div>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/isotope/isotope.pkgd.min.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
    </body>
</html>
