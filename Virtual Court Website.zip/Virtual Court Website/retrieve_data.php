<?php
  // Connect to the MySQL database
  $servername = 'localhost';
  $username = 'root';
  $password = '';
  $dbname = 'virtual court';

  // Create a connection
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Retrieve the data from the table
  $sql = "SELECT * FROM appointment";
  $result = $conn->query($sql);

  // Output the data in JSON format
  $data = array();
  while ($row = $result->fetch_assoc()) {
    $data[] = $row;
  }
  echo json_encode($data);

  // Close the connection
  $conn->close();
?>