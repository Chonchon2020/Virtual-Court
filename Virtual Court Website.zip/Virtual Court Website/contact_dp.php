<?php
// Configuration
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'virtual court';

// Create connection
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Booking form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Initialize variables with default values
    $name = '';
    $email = '';
    $subject = '';
    $message = '';
    


    // Check if form fields are set
    if (isset($_POST['name'])) {
        $name = trim($_POST['name']);
    }
    if (isset($_POST['email'])) {
        $email = trim($_POST['email']);
    }
    if (isset($_POST['subject'])) {
        $subject = trim($_POST['subject']);
    }
    if (isset($_POST['message'])) {
        $message = trim($_POST['message']);
    }

    $sql = "INSERT INTO contact (name,email,subject,message) VALUES{'$name','$email','$subject','$message')";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "Prepare failed: " . $conn->error;
    } else {
        $stmt->bind_param("sssssss", $name, $email, $subject, $message);
        if (!$stmt->execute()) {
            echo "Execute failed: " . $stmt->error;
        } else {
            header('Location: index.php');
        }
        $stmt->close();
    }
}


// Close connection
$conn->close();
?>