<?php
// Configuration
$db_host = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'virtual court';

// Create connection
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Booking form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Initialize variables with default values
    $name = '';
    $email = '';
    $contact = '';
    $location = '';
    $arrival = '';
    $time = '';
    $courts = '';
    $building = '';
    $courtroom = '';
    $message = '';
    $case = '';


    // Check if form fields are set
    if (isset($_POST['name'])) {
        $name = trim($_POST['name']);
    }
    if (isset($_POST['email'])) {
        $email = trim($_POST['email']);
    }
    if (isset($_POST['contact'])) {
        $contact = trim($_POST['contact']);
    }
    if (isset($_POST['location'])) {
        $location = trim($_POST['location']);
    }
    if (isset($_POST['arrival'])) {
        $arrival = trim($_POST['arrival']);
    }
    if (isset($_POST['time'])) {
        $time = trim($_POST['time']);
    }
    if (isset($_POST['courts'])) {
        $courts = trim($_POST['courts']);
    }
    if (isset($_POST['building'])) {
        $building = trim($_POST['building']);
    }
    if (isset($_POST['courtroom'])) {
        $courtroom = trim($_POST['courtroom']);
    }
    if (isset($_POST['message'])) {
        $message = trim($_POST['message']);
    }
    

    // Validate input
    
        // Insert data into database
        $sql = "INSERT INTO appointment (name, email, contact, location, arrival, time, courts,building,courtroom,message) VALUES ('$name', '$email', '$contact', '$location', '$arrival', '$time', '$courts', '$building','$courtroom','$message')";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            echo "Prepare failed: " . $conn->error;
        } else {
           // $stmt->bind_param("sssssss", $name, $email, $school, $arrival, $year, $room, $hostel_name);
            if (!$stmt->execute()) {
                echo "Execute failed: " . $stmt->error;
            } else {
                header('Location: message.php');
            }
            $stmt->close();
        }
    }


// Close connection
$conn->close();
?>
