-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2024 at 09:39 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.3.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `virtual court`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `arrival` date DEFAULT NULL,
  `courts` varchar(255) DEFAULT NULL,
  `building` varchar(255) DEFAULT NULL,
  `courtroom` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `name`, `email`, `contact`, `location`, `arrival`, `courts`, `building`, `courtroom`, `message`, `time`) VALUES
(1, 'Asiedu Asare Baffour Junior', 'baffourasiedu3@gmail.com', '0545473591', 'Asokwa', '2024-09-27', 'District Court', 'Asokwa Court', 'Asokwa District Court 1', 'I hope to hear from you soon', '12:00:00'),
(2, 'Asiedu Asare Baffour Junior', 'baffourasiedu3@gmail.com', '0545473591', 'Asokwa', '2024-09-27', 'District Court', 'Asokwa Court', 'Asokwa District Court 1', 'I hope to hear from you soon', '12:00:00'),
(3, 'Asiedu Asare Baffour Junior', 'baffourasiedu3@gmail.com', '0545473591', 'Asokwa', '2024-09-30', 'District Court', 'Asokwa Court', 'Asokwa District Court 1', 'one two three', '12:30:00'),
(4, 'Kofi Junior', 'baffourasiedu3@gmail.com', '0509158066', 'Asokwa', '2024-09-30', 'District Court', 'Asokwa Court', 'Asokwa District Court 2', 'Good work', '10:00:00'),
(5, 'Alfred Mensah', 'alfredmensah33@gmail.com', '0509158066', 'Atonsu', '2024-10-11', 'Court of Appeal', 'Court of Appeal', 'High Court 2', 'I really appreciate it if you can come and do this case for me', '09:00:00'),
(6, 'Kofi Junior', 'baffourasiedu3@gmail.co.com', '0509158066', 'Asokwa', '2024-10-18', 'Court of Appeal', 'Asokwa Court', 'Asokwa District Court 2', 'Family Case', '13:40:00');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
